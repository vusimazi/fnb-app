import { DetailedBalanceCheque } from './detailed-balance-cheque'

export interface DetailedBalanceSavingsInitData {
}

/** Provides access to all data FNB provide for the detailed balance of a savings account. */
export class DetailedBalanceSavings extends DetailedBalanceCheque {
}
