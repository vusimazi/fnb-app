/** Provides access to all data FNB provide for the detailed balance of an account. */
export interface DetailedBalance {
	
}
