/** The status of a transaction. */
export enum TransactionStatus {
	Successful = 'Successful',
	Pending = 'Pending'
}
