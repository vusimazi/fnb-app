module.exports = {
  printWidth: 160,
  semi: false,
  singleQuote: true,
  arrowParens: 'always'
}
